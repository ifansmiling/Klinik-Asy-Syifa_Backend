// Database.js
import { Sequelize } from "sequelize";

const db = new Sequelize(
  "jlwdtptq_db_klinik",
  "jlwdtptq_admin",
  "LxC&5*,gn!%.",
  {
    host: "api.klinikasysyifa.my.id",
    dialect: "mysql",
  }
);

export default db;
